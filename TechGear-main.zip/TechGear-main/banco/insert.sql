INSERT INTO Aluno (num_matricula, nome, turma, email, senha) VALUES
(12345678, 'João', 'joao@example.com', 'A101', 'senha123'),
(99924591, 'Maria', 'maria@example.com', 'B202', 'abc123'),
(01327482, 'Pedro','pedro@example.com', 'C303', 'pass456');

INSERT INTO Professor (nif, nome, email, senha) VALUES
(80070977, 'Silva', 'silva@example.com', 'ola'),
(20254394, 'Santos', 'santos@example.com', 'oba'),
(30356475, 'Oliveira', 'oliveira@example.com', 'bom');
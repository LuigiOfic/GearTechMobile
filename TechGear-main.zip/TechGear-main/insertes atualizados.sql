INSERT INTO alunos (numMatri, nome, sobrenome, email, senha)
VALUES
    ('12345', 'Leon', 'Kennedy', 'leonK@email.com','12345'),
    ('09876', 'Ada', 'Wong', 'AdaW@email.com', '13579'),
    ('56418', 'Chris', 'Redfield', 'ChrisrR@email.com','23641'),
    ('45010', 'Jake', ' Muller','jakeM@email.com',"35790"),
    ('22449', 'Jill', 'Valentine','jillV@email.com',"11237"),
    ('12740', 'Claire', 'Redfield','Claire@email.com',"91737"),
	('12456', 'Lara', 'Cloft','LaraC@email.com',"99937"),
    ('12921', 'Sonya', 'Blade','sonya@email.com',"00939"),
    ('88521', 'Johnny', 'Cage','Johnny@email.com',"10839"),
    ('68991', 'Carl', 'Johnson', 'Carl@email.com',"18889");
    
    
    INSERT INTO professores (nif, nome, sonrenome, email, senha)
    VALUES
    ('19573', 'Trevor', 'Philips','tp@email.com',"99937"),
    ('12456', 'Franklin', 'Clinton','fc@email.com',"99937"),
    ('12345', 'Michael', 'De Santa', 'michal@email.com','12345');
    
    
    
    
// src/App.js
import React from 'react';
import Routes from './src/routes';

function App() {
  return (
    <Routes />
  );
}

export default App;
